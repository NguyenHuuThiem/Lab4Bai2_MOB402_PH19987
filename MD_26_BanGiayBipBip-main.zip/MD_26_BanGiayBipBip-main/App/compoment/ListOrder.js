import React from 'react';
import {View} from "react-native-web";

function ListOrder(props) {
    return (
       <View></View>
    );
}

export default ListOrder;